import asyncio
import logging
import signal
import sys
from contextlib import asynccontextmanager
from typing import Optional
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse
import redis.asyncio as redis
import time
import uvicorn
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from datetime import datetime, timedelta

from .config import get_settings
from .database import DataManager, data_refresh_task
from .cache import CacheManager, cache_maintenance_task
from .udf_handlers import UDFHandler
from .monitoring import (
    health_monitor, metrics_update_task,
    track_request_metrics, update_db_pool_metrics
)
from .models import HealthResponse, CacheStats

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='{"time": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "message": "%(message)s"}'
)
logger = logging.getLogger(__name__)

# Global instances
settings = get_settings()
data_manager: Optional[DataManager] = None
cache_manager: Optional[CacheManager] = None
redis_client: Optional[redis.Redis] = None

# Background tasks
background_tasks = []

# Task supervisor for automatic task restart
async def task_supervisor():
    """Supervise background tasks and restart them if they fail"""
    global data_manager, cache_manager
    
    task_configs = [
        {"name": "cache_maintenance", "func": cache_maintenance_task, "args": [cache_manager]},
        {"name": "data_refresh", "func": data_refresh_task, "args": [data_manager]},
        {"name": "metrics_update", "func": metrics_update_task, "args": []},
        {"name": "health_check", "func": health_check_task, "args": []}
    ]
    
    running_tasks = {}
    
    while True:
        try:
            # Check each task and restart if needed
            for config in task_configs:
                task_name = config["name"]
                
                # Check if task is running and healthy
                if task_name in running_tasks:
                    task = running_tasks[task_name]
                    if task.done():
                        # Task finished (likely due to error)
                        try:
                            await task  # This will raise the exception if there was one
                        except Exception as e:
                            logger.error(f"Task {task_name} failed: {e}", exc_info=True)
                        
                        # Remove from running tasks
                        del running_tasks[task_name]
                
                # Start task if not running
                if task_name not in running_tasks:
                    logger.info(f"Starting task: {task_name}")
                    task = asyncio.create_task(config["func"](*config["args"]))
                    running_tasks[task_name] = task
            
            # Wait before next check
            await asyncio.sleep(30)
            
        except Exception as e:
            logger.error(f"Task supervisor error: {e}", exc_info=True)
            await asyncio.sleep(30)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle"""
    global data_manager, cache_manager, redis_client
    
    try:
        # Startup
        logger.info("Starting TradingView ML Visualization API")
        
        # Initialize Redis
        redis_client = redis.from_url(
            settings.redis_url,
            decode_responses=True,
            socket_timeout=settings.redis_socket_timeout,
            socket_connect_timeout=settings.redis_socket_connect_timeout
        )
        await redis_client.ping()
        logger.info("Redis connection established")
        health_monitor.update_redis_health(True)
        
        # Initialize cache manager
        cache_manager = CacheManager(redis_client)
        
        # Initialize data manager
        data_manager = DataManager(cache_manager)
        await data_manager.initialize()
        health_monitor.update_db_health(True)
        
        # Include UDF routes immediately after data manager is ready
        udf_handler = UDFHandler(data_manager)
        app.include_router(udf_handler.get_router())
        logger.info("UDF routes included successfully")
        
        # Start task supervisor to manage background tasks
        background_tasks.append(
            asyncio.create_task(task_supervisor())
        )
        
        logger.info("All systems initialized successfully")
        
        yield
        
    except Exception as e:
        logger.error(f"Startup failed: {e}")
        raise
    finally:
        # Shutdown
        logger.info("Shutting down...")
        
        # Cancel background tasks
        for task in background_tasks:
            task.cancel()
        await asyncio.gather(*background_tasks, return_exceptions=True)
        
        # Close connections
        if data_manager:
            await data_manager.close()
        if redis_client:
            await redis_client.close()
        
        logger.info("Shutdown complete")

# Create FastAPI app
app = FastAPI(
    title=settings.api_title,
    version=settings.api_version,
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=settings.cors_credentials,
    allow_methods=settings.cors_methods,
    allow_headers=settings.cors_headers,
)

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    
    # Track metrics
    track_request_metrics(
        request.method,
        request.url.path,
        response.status_code,
        process_time
    )
    
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Health check endpoint
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        # Check database
        if data_manager:
            pool_stats = await data_manager.get_pool_stats()
            update_db_pool_metrics(pool_stats)
            health_monitor.update_db_health(pool_stats.get("size", 0) > 0)
        
        # Check Redis
        if redis_client:
            await redis_client.ping()
            health_monitor.update_redis_health(True)
        
        # Get cache stats
        cache_stats = CacheStats()
        if cache_manager:
            stats = cache_manager.get_stats()
            cache_stats = CacheStats(
                l1_hits=stats.get("l1_hits", 0),
                l2_hits=stats.get("l2_hits", 0),
                l3_hits=stats.get("l3_hits", 0),
                total_misses=stats.get("total_misses", 0),
                hit_rate=stats.get("hit_rate", 0.0),
                memory_cache_size=stats.get("memory_cache_size", 0),
                redis_keys=await redis_client.dbsize() if redis_client else 0
            )
        
        health_status = health_monitor.get_health_status()
        
        return HealthResponse(
            status=health_status["status"],
            database=health_status["database"],
            redis=health_status["redis"],
            cache_stats=cache_stats,
            uptime=health_status["uptime"],
            version=settings.api_version
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            database="unknown",
            redis="unknown",
            cache_stats=CacheStats(),
            uptime=0,
            version=settings.api_version
        )

# Metrics endpoint
@app.get("/metrics")
async def get_metrics():
    """Prometheus metrics endpoint"""
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

# Cache stats endpoint
@app.get("/cache/stats")
async def get_cache_stats():
    """Get detailed cache statistics"""
    if not cache_manager:
        return {"error": "Cache not initialized"}
    
    stats = cache_manager.get_stats()
    
    # Add Redis info
    if redis_client:
        try:
            info = await redis_client.info()
            stats["redis_memory"] = info.get("used_memory_human", "unknown")
            stats["redis_keys"] = await redis_client.dbsize()
        except:
            pass
    
    return stats

# Label distribution endpoint
@app.get("/api/label-distribution")
async def get_label_distribution(
    timeframe: str = "5min",
    days: int = 7
):
    """Get ML label distribution"""
    if not data_manager:
        return {"error": "Data manager not initialized"}
    
    from_date = datetime.now() - timedelta(days=days)
    distribution = await data_manager.get_label_distribution(
        timeframe, from_date
    )
    
    return {
        "timeframe": timeframe,
        "period_days": days,
        "distribution": distribution
    }

# UDF routes will be included after startup

# Background health check
async def health_check_task(interval: int = 30):
    """Periodic health checks"""
    while True:
        try:
            await asyncio.sleep(interval)
            
            # Check database
            if data_manager and data_manager.pool:
                try:
                    async with data_manager.pool.acquire() as conn:
                        await asyncio.wait_for(conn.fetchval("SELECT 1"), timeout=5)
                    health_monitor.update_db_health(True)
                except:
                    health_monitor.update_db_health(False)
            
            # Check Redis
            if redis_client:
                try:
                    await redis_client.ping()
                    health_monitor.update_redis_health(True)
                except:
                    health_monitor.update_redis_health(False)
                    
        except Exception as e:
            logger.error(f"Health check task error: {e}")

# Graceful shutdown handler
def signal_handler(sig, frame):
    logger.info(f"Received signal {sig}")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Import after app creation to avoid circular imports

# UDF routes are now included directly in the lifespan function

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        workers=4,
        log_config={
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": '{"time": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}',
                },
            },
            "handlers": {
                "default": {
                    "formatter": "default",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout",
                },
            },
            "root": {
                "level": "INFO",
                "handlers": ["default"],
            },
        }
    )