import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './',
  server: {
    port: 3000,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true,
        rewrite: (path: string) => path.replace(/^\/api/, '')
      },
      '/config': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      },
      '/symbols': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      },
      '/search': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      },
      '/history': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      },
      '/marks': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      },
      '/timescale_marks': {
        target: 'http://5.223.52.98:8888',
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets'
  }
})