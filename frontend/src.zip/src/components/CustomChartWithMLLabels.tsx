import React, { useEffect, useRef, useState } from 'react'
import { createChart, IChartApi, ColorType, CrosshairMode, LineStyle, Time } from 'lightweight-charts'
import { HistoryData } from '../types'

interface CustomChartProps {
  symbol: string
  interval: string
  height?: string
}

// Simplified label mapping
const SIMPLIFIED_LABELS: { [key: string]: string } = {
  'Very Bearish': 'Bearish',
  'Bearish': 'Bearish',
  'Somewhat Bearish': 'Bearish',
  'Neutral': 'Neutral',
  'Somewhat Bullish': 'Bullish',
  'Bullish': 'Bullish',
  'Very Bullish': 'Bullish'
}

const SIMPLIFIED_COLORS = {
  'Bearish': '#ef5350',
  'Neutral': '#ffa726',
  'Bullish': '#26a69a'
}

const CustomChartWithMLLabels: React.FC<CustomChartProps> = ({ 
  symbol, 
  interval,
  height = '500px'
}) => {
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candleSeriesRef = useRef<any>(null)
  const lineSeriesRef = useRef<any>(null)
  const chartTypeRef = useRef<'line' | 'candle'>('candle')
  const isUserInteraction = useRef(false)
  
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [chartType, setChartType] = useState<'line' | 'candle'>('candle')
  
  // Debug chartType changes with stack trace
  useEffect(() => {
    console.log('ChartType changed to:', chartType)
    console.trace('ChartType change stack trace')
  }, [chartType])
  
  // Debug interval prop changes
  useEffect(() => {
    console.log('Chart: interval prop changed to:', interval)
  }, [interval])
  const [mlLabels, setMlLabels] = useState<any[]>([])
  const [chartData, setChartData] = useState<any[]>([])

  // Format time for x-axis (will be added back later)
  // const timeFormatter = (time: Time) => {
  //   const date = new Date(time as number * 1000)
  //   const hours = date.getHours().toString().padStart(2, '0')
  //   const minutes = date.getMinutes().toString().padStart(2, '0')
  //   return `${hours}:${minutes}`
  // }

  // Create chart once on mount
  useEffect(() => {
    console.log('Chart initialization useEffect triggered')
    
    const createChartInstance = () => {
      console.log('Attempting to create chart, container ref:', chartContainerRef.current)
      
      if (chartContainerRef.current && !chartRef.current) {
        console.log('Creating chart for the first time, container:', chartContainerRef.current)
        
        // Create chart only once
        const chart = createChart(chartContainerRef.current, {
          layout: {
            background: { type: ColorType.Solid, color: '#131722' },
            textColor: '#d1d4dc',
          },
          grid: {
            vertLines: { color: '#2a2e39' },
            horzLines: { color: '#2a2e39' },
          },
          crosshair: {
            mode: CrosshairMode.Normal,
            vertLine: {
              width: 1,
              color: '#787b86',
              style: LineStyle.Dashed,
            },
            horzLine: {
              width: 1,
              color: '#787b86',
              style: LineStyle.Dashed,
            },
          },
          rightPriceScale: {
            borderColor: '#2a2e39',
          },
          timeScale: {
            borderColor: '#2a2e39',
            timeVisible: true,
            secondsVisible: false,
          },
          width: chartContainerRef.current.clientWidth,
          height: 400, // Fixed height for debugging
        })

        console.log('Chart created with dimensions:', chartContainerRef.current.clientWidth, 'x', 400)
        chartRef.current = chart
        
        // Create initial candlestick series (we'll switch it later if needed)
        const candleSeries = (chart as any).addCandlestickSeries({
          upColor: '#26a69a',
          downColor: '#ef5350',
          borderUpColor: '#26a69a',
          borderDownColor: '#ef5350',
          wickUpColor: '#26a69a',
          wickDownColor: '#ef5350',
        })
        candleSeriesRef.current = candleSeries
        console.log('Initial candlestick series created:', candleSeries)
      } else if (!chartContainerRef.current) {
        console.log('Container not ready yet, retrying in 100ms...')
        setTimeout(createChartInstance, 100)
      }
    }
    
    // Try immediately, then retry if needed
    createChartInstance()

    // Resize handler
    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
        })
      }
    }
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      if (chartRef.current) {
        try {
          chartRef.current.remove()
        } catch (error) {
          console.warn('Error removing chart:', error)
        }
      }
    }
  }, []) // No dependencies - only run once

  // Combined effect for series management
  useEffect(() => {
    console.log('Series useEffect triggered, chartType:', chartType, 'data points:', chartData.length)
    
    if (!chartRef.current || chartData.length === 0) {
      console.log('Chart not ready or no data, skipping')
      return
    }
    
    // Skip if we already have the correct series type with data
    if (chartType === 'candle' && candleSeriesRef.current) {
      console.log('Candlestick series exists, updating data only')
      const formattedData = chartData.map(d => ({
        time: d.time as Time,
        open: d.open,
        high: d.high,
        low: d.low,
        close: d.close
      }))
      candleSeriesRef.current.setData(formattedData)
      chartRef.current.timeScale().fitContent()
      return
    }
    
    if (chartType === 'line' && lineSeriesRef.current) {
      console.log('Line series exists, updating data only')
      const formattedData = chartData.map(d => ({
        time: d.time as Time,
        value: d.close
      }))
      lineSeriesRef.current.setData(formattedData)
      chartRef.current.timeScale().fitContent()
      return
    }
    
    console.log('Creating new series for:', chartType, 'with', chartData.length, 'data points')
    
    // Clear all existing series
    if (candleSeriesRef.current) {
        try {
          chartRef.current.removeSeries(candleSeriesRef.current)
          console.log('Removed candlestick series')
        } catch (error) {
          console.warn('Error removing candle series:', error)
        }
        candleSeriesRef.current = null
      }
      if (lineSeriesRef.current) {
        try {
          chartRef.current.removeSeries(lineSeriesRef.current)
          console.log('Removed line series')
        } catch (error) {
          console.warn('Error removing line series:', error)
        }
        lineSeriesRef.current = null
      }

      // Create new series and set data immediately
      if (chartType === 'candle') {
        const candleSeries = (chartRef.current as any).addCandlestickSeries({
          upColor: '#26a69a',
          downColor: '#ef5350',
          borderUpColor: '#26a69a',
          borderDownColor: '#ef5350',
          wickUpColor: '#26a69a',
          wickDownColor: '#ef5350',
        })
        candleSeriesRef.current = candleSeries
        console.log('Candlestick series created:', candleSeries)
        
        // Set data immediately
        const formattedData = chartData.map(d => ({
          time: d.time as Time,
          open: d.open,
          high: d.high,
          low: d.low,
          close: d.close
        }))
        candleSeries.setData(formattedData)
        console.log('Candlestick data set with', formattedData.length, 'points')
      } else {
        const lineSeries = (chartRef.current as any).addLineSeries({
          color: '#2962ff',
          lineWidth: 2,
        })
        lineSeriesRef.current = lineSeries
        console.log('Line series created:', lineSeries)
        
        // Set data immediately
        const formattedData = chartData.map(d => ({
          time: d.time as Time,
          value: d.close
        }))
        lineSeries.setData(formattedData)
        console.log('Line data set with', formattedData.length, 'points')
      }

      // ML markers are handled by separate useEffect
      
      // Fit content
      chartRef.current.timeScale().fitContent()
      console.log('Chart content fitted')
    }
  }, [chartType, chartData])

  // Separate effect just for ML markers to avoid triggering series recreation
  useEffect(() => {
    if (mlLabels.length > 0) {
      const currentSeries = chartType === 'candle' ? candleSeriesRef.current : lineSeriesRef.current
      if (currentSeries) {
        // Filter labels to show only when they change
        const filteredLabels = mlLabels.filter((label, index) => {
          if (index === 0) return true
          const prevLabel = mlLabels[index - 1]
          return prevLabel?.text !== label.text
        })

        // Add markers for filtered labels
        const markers = filteredLabels.map(label => {
          const simplifiedLabel = SIMPLIFIED_LABELS[label.text] || label.text
          const color = SIMPLIFIED_COLORS[simplifiedLabel as keyof typeof SIMPLIFIED_COLORS] || label.color

          return {
            time: label.time as Time,
            position: 'aboveBar' as const,
            color: color,
            shape: 'circle' as const,
            text: simplifiedLabel,
          }
        })

        currentSeries.setMarkers(markers)
        console.log('ML markers updated separately:', markers.length)
      }
    }
  }, [mlLabels, chartType])

  useEffect(() => {
    const fetchDataWithDeps = async () => {
      try {
        console.log('Fetching data for interval:', interval)
        setLoading(true)
        const endTime = 1753457340
        const startTime = 1752845100
        
        const historyUrl = `/history?symbol=${symbol}&from=${startTime}&to=${endTime}&resolution=${interval}`
        const marksUrl = `/marks?symbol=${symbol}&from=${startTime}&to=${endTime}&resolution=${interval}`
        
        console.log('Fetching from URLs:', historyUrl, marksUrl)
        
        const [historyRes, marksRes] = await Promise.all([
          fetch(historyUrl),
          fetch(marksUrl)
        ])

        console.log('Response status:', historyRes.status, marksRes.status)

        if (!historyRes.ok || !marksRes.ok) {
          throw new Error(`Failed to fetch data: history ${historyRes.status}, marks ${marksRes.status}`)
        }

        const historyData: HistoryData = await historyRes.json()
        const marksData = await marksRes.json()

        console.log('Received data:', {
          historyStatus: historyData.s,
          historyPoints: historyData.t?.length || 0,
          marksCount: marksData.marks?.length || 0
        })

        if (historyData.s === 'ok' && historyData.t && historyData.t.length > 0) {
          const formattedChartData = historyData.t.map((timestamp: number, index: number) => ({
            time: timestamp,
            open: historyData.o?.[index] || 0,
            high: historyData.h?.[index] || 0,
            low: historyData.l?.[index] || 0,
            close: historyData.c?.[index] || 0,
          }))
          
          console.log('Setting chart data:', formattedChartData.length, 'points')
          setChartData(formattedChartData)
          
          // Process ML labels
          const processedLabels = marksData.marks?.map((mark: any) => ({
            time: mark.time,
            text: mark.text,
            color: mark.color
          })) || []
          
          setMlLabels(processedLabels)
        }
        
        setError(null)
      } catch (error) {
        console.error('Error fetching data:', error)
        setError(error instanceof Error ? error.message : 'Failed to fetch data')
      } finally {
        setLoading(false)
      }
    }

    fetchDataWithDeps()
    const intervalId = setInterval(fetchDataWithDeps, 60000)
    return () => clearInterval(intervalId)
  }, [symbol, interval])




  if (loading) {
    return (
      <div style={{ 
        height, 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        color: '#787b86'
      }}>
        Loading chart data...
      </div>
    )
  }

  if (error) {
    return (
      <div style={{ 
        height, 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        color: '#ef5350'
      }}>
        Error: {error}
      </div>
    )
  }

  return (
    <div style={{ height, width: '100%', position: 'relative' }}>
      <div style={{ 
        padding: '10px 20px', 
        borderBottom: '1px solid #2a2e39',
        background: '#131722'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#d1d4dc' }}>
          {symbol} - Custom Chart with ML Labels
        </h3>
        <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: '#787b86' }}>
          Data from your TimescaleDB | {chartData.length} data points | {mlLabels.length} ML predictions
        </p>
      </div>
      
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        padding: '10px 20px',
        background: '#131722'
      }}>
        <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
          {mlLabels.length > 0 && (
            <div style={{ 
              display: 'flex', 
              alignItems: 'center',
              gap: '8px',
              padding: '4px 8px',
              background: 'rgba(19, 23, 34, 0.8)',
              border: `1px solid ${SIMPLIFIED_COLORS[SIMPLIFIED_LABELS[mlLabels[mlLabels.length - 1]?.text] as keyof typeof SIMPLIFIED_COLORS]}`,
              borderRadius: '4px'
            }}>
              <div style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: SIMPLIFIED_COLORS[SIMPLIFIED_LABELS[mlLabels[mlLabels.length - 1]?.text] as keyof typeof SIMPLIFIED_COLORS]
              }} />
              <span style={{ 
                color: SIMPLIFIED_COLORS[SIMPLIFIED_LABELS[mlLabels[mlLabels.length - 1]?.text] as keyof typeof SIMPLIFIED_COLORS], 
                fontSize: '11px',
                fontWeight: 'bold'
              }}>
                Latest: {SIMPLIFIED_LABELS[mlLabels[mlLabels.length - 1]?.text]}
              </span>
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => {
              isUserInteraction.current = true
              setChartType('line')
            }}
            style={{
              padding: '5px 15px',
              borderRadius: '4px',
              border: '1px solid #2a2e39',
              background: chartType === 'line' ? '#26a69a' : '#131722',
              color: chartType === 'line' ? '#fff' : '#787b86',
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            Line Chart
          </button>
          <button
            onClick={() => setChartType('candle')}
            style={{
              padding: '5px 15px',
              borderRadius: '4px',
              border: '1px solid #2a2e39',
              background: chartType === 'candle' ? '#26a69a' : '#131722',
              color: chartType === 'candle' ? '#fff' : '#787b86',
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            Candlestick
          </button>
        </div>
      </div>
      
      <div 
        ref={chartContainerRef} 
        style={{ 
          position: 'relative', 
          width: '100%', 
          height: '400px',
          border: '1px solid #2a2e39',
          backgroundColor: '#131722'
        }} 
      />
      
      {/* Simplified Legend */}
      <div style={{
        position: 'absolute',
        bottom: '10px',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        gap: '15px',
        background: 'rgba(19, 23, 34, 0.9)',
        padding: '5px 10px',
        borderRadius: '4px',
        fontSize: '11px'
      }}>
        {Object.entries(SIMPLIFIED_COLORS).map(([label, color]) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center' }}>
            <div style={{
              width: '10px',
              height: '10px',
              borderRadius: '50%',
              backgroundColor: color,
              marginRight: '5px'
            }} />
            <span style={{ color: '#787b86' }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default CustomChartWithMLLabels