import React, { useState, useEffect } from 'react'
import CustomChartWithMLLabels from './components/CustomChartWithMLLabels'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import { HealthStatus, CacheStats, LabelDistribution } from './types'
import { fetchHealth, fetchCacheStats } from './services/api'

const App: React.FC = () => {
  const [health, setHealth] = useState<HealthStatus | null>(null)
  const [cacheStats, setCacheStats] = useState<CacheStats | null>(null)
  const [labelDistribution] = useState<LabelDistribution | null>(null)
  const [selectedTimeframe, setSelectedTimeframe] = useState('1')
  
  // Debug timeframe changes
  useEffect(() => {
    console.log('App: selectedTimeframe changed to:', selectedTimeframe)
  }, [selectedTimeframe])
  const [appLoaded, setAppLoaded] = useState(false)

  useEffect(() => {
    // Mark app as loaded first
    setAppLoaded(true)
    
    // Then fetch data
    fetchData()

    // Set up polling
    const interval = setInterval(fetchData, 30000) // Every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const fetchData = async () => {
    try {
      const [healthData, cacheData] = await Promise.all([
        fetchHealth(),
        fetchCacheStats()
        // Skip label distribution for now - using historical data
      ])
      
      setHealth(healthData)
      setCacheStats(cacheData)
      // setLabelDistribution(labelData)
    } catch (error) {
      console.error('Error fetching data:', error)
    }
  }

  if (!appLoaded) {
    return (
      <div className="loading-spinner">
        Initializing TradingView ML Visualization...
      </div>
    )
  }

  return (
    <div className="app-container">
      <Header health={health} />
      
      <div className="main-content">
        <div className="chart-container">
          {/* Chart Header */}
          <div style={{
            position: 'absolute',
            top: '15px',
            left: '15px',
            zIndex: 1000,
            background: 'rgba(19, 23, 34, 0.98)',
            border: '2px solid #26a69a',
            borderRadius: '8px',
            padding: '8px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: '15px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
            width: 'auto',
            whiteSpace: 'nowrap'
          }}>
            <div style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#d1d4dc'
            }}>
              🤖 NIFTY50 with ML Predictions
            </div>
            <div style={{
              fontSize: '12px',
              color: '#26a69a',
              background: '#1e222d',
              padding: '4px 8px',
              borderRadius: '4px',
              border: '1px solid #26a69a'
            }}>
              {selectedTimeframe === 'D' ? 'Daily' : selectedTimeframe === 'W' ? 'Weekly' : selectedTimeframe === 'M' ? 'Monthly' : `${selectedTimeframe} min`}
            </div>
            <div style={{
              fontSize: '11px',
              color: '#787b86',
              background: '#1e222d',
              padding: '3px 6px',
              borderRadius: '3px',
              border: '1px solid #2a2e39'
            }}>
              📅 July 18-25, 2025
            </div>
          </div>

          {/* Timeframe Selector */}
          <div style={{
            position: 'absolute',
            top: '15px',
            right: '15px',
            zIndex: 1000,
            background: 'rgba(19, 23, 34, 0.95)',
            border: '1px solid #2a2e39',
            borderRadius: '6px',
            padding: '6px',
            display: 'flex',
            gap: '4px',
            flexWrap: 'wrap',
            maxWidth: '300px'
          }}>
            {['1', '2', '3', '5', '10', '15', '30', '60', 'D', 'W', 'M'].map((timeframe) => (
              <button
                key={timeframe}
                onClick={() => setSelectedTimeframe(timeframe)}
                style={{
                  backgroundColor: selectedTimeframe === timeframe ? '#26a69a' : '#2a2e39',
                  color: selectedTimeframe === timeframe ? '#000' : '#d1d4dc',
                  border: 'none',
                  borderRadius: '3px',
                  padding: '4px 8px',
                  fontSize: '11px',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  fontWeight: selectedTimeframe === timeframe ? 'bold' : 'normal'
                }}
                onMouseEnter={(e) => {
                  if (selectedTimeframe !== timeframe) {
                    e.currentTarget.style.backgroundColor = '#3a3e49'
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedTimeframe !== timeframe) {
                    e.currentTarget.style.backgroundColor = '#2a2e39'
                  }
                }}
              >
                {timeframe === 'D' ? 'Day' : timeframe === 'W' ? 'Week' : timeframe === 'M' ? 'Month' : `${timeframe}m`}
              </button>
            ))}
          </div>

          <CustomChartWithMLLabels
            symbol="NIFTY50"
            interval={selectedTimeframe}
            height="100%"
          />
        </div>
        
        <Sidebar
          health={health}
          cacheStats={cacheStats}
          labelDistribution={labelDistribution}
          selectedTimeframe={selectedTimeframe}
        />
      </div>
    </div>
  )
}

export default App